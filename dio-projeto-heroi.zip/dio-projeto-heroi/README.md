# 🧙‍♂️ Projeto: Classes de um Jogo | DIO

Este projeto é um exercício prático da DIO, com o objetivo de aplicar conceitos básicos da programação orientada a objetos, utilizando **classes**, **objetos**, **métodos** e **estruturas condicionais** em JavaScript.

## 🎯 Objetivo

Criar uma classe `Heroi` com as propriedades:
- `nome`
- `idade`
- `tipo` (ex: mago, guerreiro, monge, ninja)

E um método `atacar()` que exiba:
- O {tipo} atacou usando {ataque}.

### Tipos e Ataques

| Tipo      | Ataque usado             |
|-----------|--------------------------|
| Mago      | magia                    |
| Guerreiro | espada                   |
| Monge     | artes marciais           |
| Ninja     | shuriken                 |

---

## 📦 Como executar

1. Clone o repositório:
```bash
git clone https://github.com/Monicasannts/dio-projeto-heroi.git
```

2. Acesse a pasta e execute com Node.js:
```bash
cd dio-projeto-heroi
node heroi.js
```

---

## 🛠️ Tecnologias

- JavaScript (ES6)
- Node.js (para execução)

---

## 👤 Autora

**Mônica dos Santos Moura**  
📍 Vitória de Santo Antão - PE  
🔗 GitHub: [Monicasannts](https://github.com/Monicasannts)

---

Feito com ❤️ durante os estudos na DIO.
